import { PROPERTIES, type PropertyDef } from "./rules.ts";
import type { GameState } from "./game.ts";
export function gameProperties(g: Pick<GameState, "customCities"> | null): Record<string, PropertyDef> {
  if (!g?.customCities || !Object.keys(g.customCities).length) return PROPERTIES;
  return Object.fromEntries(Object.entries(PROPERTIES).map(([id, p]) => {
    const c = g.customCities?.[id];
    return [id, c ? {...p, name:c.name, price:c.price, rent:p.rent.map(n=>Math.max(1,Math.round(n*c.price/p.price))), buildCost:Math.max(10,Math.round(p.buildCost*c.price/p.price))} : p];
  }));
}
