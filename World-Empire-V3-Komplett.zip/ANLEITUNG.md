# World Empire 3 – Update mit 24 Verbesserungen

## Veröffentlichen

worker.js enthält das komplette Spiel und den Multiplayer-Server.
wrangler.json richtet den Raumspeicher ein. Beide Dateien liegen im ZIP
oben und müssen im GitHub-Repository ebenfalls oben liegen.
Ersetze die bisherigen beiden Dateien und lasse Cloudflare neu deployen.
Worker-Name: world-empire-online (muss zu deinem vorhandenen Worker passen).
Build command: leer. Deploy command: npx --yes wrangler@4.135.0 deploy
Root directory: Hauptverzeichnis. Nicht Upload static files verwenden.
Bestehende Durable-Object-Migrationen beim Update beibehalten.

Falls dein bisheriger Worker anders heißt, übernimm dessen Namen in
wrangler.json, statt versehentlich einen zweiten Worker anzulegen.
Neue Funktionen am besten in einem neuen Raum testen. Eine aktive Partie
vorher beenden; ein Server-Update kann Verbindungen kurz unterbrechen.
Es wurde nichts in deinem Cloudflare-Konto veröffentlicht.

## Neu und verbessert

1. Mobile Bedienung: größere Aktionen, feste Geld-/Pausezeile, Grundstückskarte als Overlay.
2. Würfeln, Kaufen, Versteigern und Zug beenden direkt unter den Würfeln.
3. 3D-Würfel mit kontinuierlicher Rotation, gedämpften Sprüngen, Schatten und exaktem Ergebnis.
4. Vier Casino-Spiele pro Zug, Roulette und Blackjack teilen dieses Limit.
5. Einsatz ab 1 € frei bis zum verfügbaren Spielgeld, ohne feste Spielgrenze.
   Technische Grenze: exakte Ganzzahlrechnung in JavaScript; keine Echtgeldfunktion.
6. Auktionen mit sichtbarem Fortschritt, Gebotsliste und bestehender Verlängerung bei späten Geboten.
7. Figuren ziehen Feld für Feld; Gebäude erscheinen animiert.
8. Kauf-/Gruppenereignisse werden hervorgehoben; Würfel- und Geldsounds bleiben abschaltbar.
9. Handel zeigt Du gibst / Du erhältst und die Angebotsvorschau; Gegenangebote bleiben verfügbar.
10. Bereitschaft in der Lobby, Verbindungsanzeige, Wiederverbinden und Revanche.
11. Hinweise auf Handelsangebote sowie App-Badges und Aktionsstatus im Handy.
12. Optionale Wirtschaftsereignisse im Plus-Modus: eine Farbgruppe erhält für eine Runde ±25 % Miete.
13. Ergebnisübersicht: Einnahmen, gezahlte Miete, Käufe und bester Auktionsrabatt.
14. Öffentliche Spieltische suchen. Der Gastgeber aktiviert die Sichtbarkeit freiwillig.
15. Zuschauen per Raumliste oder Raumcode. In der nächsten Lobby auf Jetzt mitspielen klicken.
16. Schnellspiel-Preset: 10 Runden, 45 Sekunden pro Zug.
17. Gemeinsam pausieren/fortsetzen. Alle verbundenen aktiven Menschen stimmen zu.
18. Stadtsets: Namen, Preise und Gruppenfarben bearbeiten, lokal speichern und laden.
    Mieten/Baukosten skalieren proportional; Gruppen und Brettpositionen bleiben gleich.
19. Drei Bot-Stärken mit verschiedenen Rücklagen, Gebots- und Handelsbewertungen.
20. Lokale Karriere: Siege, Serie, Einnahmen, Käufe, häufigste Städte und Spielgewinne.
21. Ozean-Design/Stern nach 1 Partie, Royal-Design/Diamant nach 3 Partien.
22. Schnelle Emoji- und Textreaktionen.
23. Tutorial begleitet Würfeln, ersten Besitz, Verwaltung und Handel.
24. Miettabelle und Vorschau auf die nächste Baustufe.
Geheime Nebenziele sind nicht enthalten.

## Speicher und Grenzen

Spielstände: auf dem Server. Bei einer gemeinsam pausierten Partie bleibt
auch nach dem Verlassen der Raumspeicher erhalten. Ohne gemeinsame Pause
werden Räume nach 24 Stunden ohne Spieler entfernt. Zum Wiederbeitritt
 denselben Browser mit erhaltenen Website-Daten und Raumcode verwenden.
Karriere, Freischaltungen und Stadtvorlagen: auf diesem Gerät/Browser;
kein Benutzerkonto und keine Synchronisierung zwischen Geräten.
Öffentliche Suche: bis zu 30 Räume aus einem begrenzten Verzeichnis;
kein globales Matchmaking oder öffentliches Ranking. Private Räume sind
nicht aufgelistet. Wer den Code kennt, kann zuschauen.

## Prüfung

TypeScript geprüft. 35 Regeltests bestanden, darunter 20 vollständige,
reproduzierbare Bot-Partien. Zwei WebSocket-Integrationstests prüfen
Spielen, Wiederverbinden, Fremd-Origins, öffentliche/private Räume und
Zuschauerrechte. Mobile Browserprüfung (390 px) mit zwei Spielersitzungen:
Bereitschaft, Start, Würfeln, Aktionen unter Würfeln, Pause/Fortsetzen,
Casino-Eingabefeld, keine JavaScript-Fehler und kein horizontaler Überlauf.
Kein Test auf einem echten iPhone und kein Produktions-Deploy durchgeführt.

## Quellcode

source/ enthält den bearbeitbaren Quellcode und Tests.
Im source-Ordner: npm ci; npm test; npm run build:release
Der letzte Befehl erzeugt ../rebuilt/worker.js und ../rebuilt/wrangler.json.
Zum lokalen Server-Test: npm run dev:worker, danach npm run test:multiplayer.
Die Third-Party-Lizenzen stehen in source/LICENSES.txt und in worker.js.

Cloudflare: https://developers.cloudflare.com/workers/ci-cd/builds/configuration/
